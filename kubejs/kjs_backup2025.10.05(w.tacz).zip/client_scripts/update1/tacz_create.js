ItemEvents.tooltip(event => {
  // Add tooltip to all of these items
  event.add(['createimmersivetacz:gun_trigger'], '为什么你要从已有的枪里切出下机匣？你就是被18 U.S.C.害了')
})